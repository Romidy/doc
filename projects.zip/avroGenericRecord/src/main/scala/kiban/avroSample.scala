package kiban

import java.io._

import com.sksamuel.avro4s.{AvroInputStream, AvroOutputStream}
import org.apache.avro.Schema
import org.apache.avro.Schema.{Field, Parser}
import org.apache.avro.generic.{GenericData, GenericRecord}
import org.apache.avro.io._
import org.apache.avro.specific.{SpecificDatumReader, SpecificDatumWriter}
import org.apache.commons.io.output.ByteArrayOutputStream

import scala.io.Source

object Avro4sMain {

  def main(args: Array[String]): Unit = {
    val fileName = "can.avro"

    //CanGenericWrite(fileName)
    //CanGenericRead(fileName)

    //CanWrite(fileName)
    //CanRead(fileName)

    //PizzaWrite(fileName)
    //PizzaRead(fileName)
    //PizzaBinaryWriteRead()

    //GenericWrite(fileName)
    //GenericRead(fileName)

    //TymGenericWrite(fileName)
    //TymGenericRead(fileName)

//    GenericCanWrite(fileName)
//    GenericCanRead(fileName)

    GenericWriteUser(fileName)
  }

  /** CAN_Genericデータ */
  case class User(id: Int, name: String, email: Option[String])

  def CanGenericWrite(file: String): Unit = {

    val can1 = User(1000000, "v001", Some("test"))
    val can2 = User(1000000, "v002", None)
    val cans = Seq(can1, can2)

    //    implicit val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    //    val os = AvroOutputStream.binary[CanGeneric](new File(file))
    val os = AvroOutputStream.binary[User](new File(file))
    os.write(cans)
    os.flush()
    os.close()
  }

  def CanGenericRead(file: String): Unit = {
    val is = AvroInputStream.binary[User](new File(file))
    val deserializedCans = is.iterator.toSet
    is.close()
    deserializedCans.foreach(rec => {
      println(s"id[${rec.id}] name[${rec.name}] email[${
        rec.email match {
          case Some(f) => f
          case None => "nothing"
        }
      }]")
    })
  }

  /** TymGenericデータ */
  def TymGenericWrite(file: String): Unit = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)

    val can1 = User(1000000, "v001", Some("test"))
    val can2 = User(1000000, "v002", None)
    val cans = Seq(can1, can2)

//    val os = AvroOutputStreamTym.binary[User](new File(file), schema)
//    os.write(cans)
//    os.flush()
//    os.close()
  }

  def TymGenericRead(file: String): Unit = {
    val bis = new BufferedInputStream(new FileInputStream(file))
    val payload = Stream.continually(bis.read).takeWhile(-1 !=).map(_.toByte).toArray

    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val reader: DatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](schema)
    val decoder: Decoder = DecoderFactory.get().binaryDecoder(payload, null)

    val record: GenericRecord = reader.read(null, decoder)

    println(record.get("id"))
    println(record.get("name"))

  }

  /** CANデータ */
  case class GpsValue(double: Double)

  case class Gps(offset: Array[Long], lat: Array[GpsValue], lon: Array[GpsValue])

  case class Can(timestamp: Long, vin: String, gps: Array[Gps])

  def CanWrite(file: String): Unit = {
    val can1 = Can(1000000, "v001", Array[Gps](Gps(Array[Long](100, 200), Array[GpsValue](GpsValue(15.1), GpsValue(15.2)), Array[GpsValue](GpsValue(135.1), GpsValue(135.2)))))
    val can2 = Can(1000000, "v002", Array[Gps](Gps(Array[Long](100, 200), Array[GpsValue](GpsValue(15.1), GpsValue(15.2)), Array[GpsValue](GpsValue(135.1), GpsValue(135.2)))))

    val cans = Seq(can1, can2)

    val os = AvroOutputStream.binary[Can](new File(file))
    os.write(cans)
    os.flush()
    os.close()
  }

  def CanRead(file: String): Unit = {
    val is = AvroInputStream.binary[Can](new File(file))
    val deserializedCans = is.iterator.toSet
    is.close()
    deserializedCans.foreach(rec => {
      println(s"vin[${rec.vin}] timestamp[${rec.timestamp}]")
      for (gps <- rec.gps) {
//                val len = gps.offset.length
//                for (i <- len) {
//
//                }
      }

    })
  }

  /** Pizzaデータ */
  case class Ingredient(name: String, sugar: Double, fat: Double)

  case class Pizza(name: String, ingredients: Seq[Ingredient], vegetarian: Boolean, vegan: Boolean, calories: Int)

  def PizzaWrite(file: String): Unit = {
    val pepperoni = Pizza("pepperoni", Seq(Ingredient("pepperoni", 12, 4.4), Ingredient("onions", 1, 0.4)), false, false, 98)
    val hawaiian = Pizza("hawaiian", Seq(Ingredient("ham", 1.5, 5.6), Ingredient("pineapple", 5.2, 0.2)), false, false, 91)
    val pizzaObjects = Seq(pepperoni, hawaiian)
    val os = AvroOutputStream.data[Pizza](new File(file))
    os.write(pizzaObjects)
    os.flush()
    os.close()
  }

  def PizzaRead(file: String): Unit = {
    val is = AvroInputStream.data[Pizza](new File(file))
    val deserializedPizzas = is.iterator.toSet
    is.close()
    deserializedPizzas.foreach(println)
  }

  def PizzaBinaryWriteRead(): Unit = {
    val pepperoni = Pizza("pepperoni", Seq(Ingredient("pepperoni", 12, 4.4), Ingredient("onions", 1, 0.4)), false, false, 98)
    val hawaiian = Pizza("hawaiian", Seq(Ingredient("ham", 1.5, 5.6), Ingredient("pineapple", 5.2, 0.2)), false, false, 91)
    val pizzaObjects = Seq(pepperoni, hawaiian)

    val baos = new ByteArrayOutputStream()
    val output = AvroOutputStream.binary[Pizza](baos)
    output.write(pizzaObjects)
    output.close()
    val bytes = baos.toByteArray

    val in = new ByteArrayInputStream(bytes)
    val input = AvroInputStream.binary[Pizza](in)
    val deserializedPizzas2 = input.iterator.toSeq
    deserializedPizzas2.foreach(println)
    in.close()
  }

  /** Genericデータ */
  def GenericWriteUser(file: String): Unit = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val can1 = User(1000000, "v001", Some("test"))

    val genericUser: GenericRecord = new GenericData.Record(schema)

    // specific writer
    val writer = new SpecificDatumWriter[User](schema)
    val out = new ByteArrayOutputStream()
    val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
    writer.write(can1, encoder)
    encoder.flush()
    out.close()
    out.toByteArray()
    val bos = new BufferedOutputStream(new FileOutputStream(file))
    bos.write(out.toByteArray())
    bos.close()
  }

  def GenericWrite(file: String): Unit = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val genericUser: GenericRecord = new GenericData.Record(schema)
    genericUser.put("id", 999999)
    genericUser.put("name", "sushil")
    genericUser.put("email", null)
    //    genericUser.put("ids", Array[Int](10, 20, 30))
    // Serialize generic record into byte array
    val writer = new SpecificDatumWriter[GenericRecord](schema)
    val out = new ByteArrayOutputStream()
    val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
    writer.write(genericUser, encoder)
    encoder.flush()
    out.close()
    out.toByteArray()
    val bos = new BufferedOutputStream(new FileOutputStream(file))
    bos.write(out.toByteArray())
    bos.close()
  }

  def GenericRead(file: String): Unit = {
    val bis = new BufferedInputStream(new FileInputStream(file))
    val payload = Stream.continually(bis.read).takeWhile(-1 !=).map(_.toByte).toArray

    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val reader: DatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](schema)
    val decoder: Decoder = DecoderFactory.get().binaryDecoder(payload, null)

    val record: GenericRecord = reader.read(null, decoder)

    println(record.get("id"))
    println(record.get("name"))

  }

  /** GenericCanデータ */
  def GenericCanWrite(file: String): Unit = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/can1.avsc")).mkString)
    println(schema)
    println(schema.getFields)
    val list = schema.getFields
    println(s"listsize[${list.size()}]")
    println(s"val[${list.get(0).name()}]")

//    for (filed: Field <- list) printf(filed.name())
    val can: GenericRecord = new GenericData.Record(schema)
    can.put("timestamp", 9000L)
    can.put("vin", "v000001")
//    val gps: GenericRecord = new GenericData.Record(schema.getField("Gps").)
//    gps.put("offset", List[Int](10,20))
//    can.put("gps", gps)

//    val writer = new SpecificDatumWriter[GenericRecord](schema)
//    val out = new ByteArrayOutputStream()
//    val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
//    writer.write(can, encoder)
//    encoder.flush()
//    out.close()
//    out.toByteArray()
//    val bos = new BufferedOutputStream(new FileOutputStream(file))
//    bos.write(out.toByteArray())
//    bos.close()
  }

  def GenericCanRead(file: String): Unit = {
    val bis = new BufferedInputStream(new FileInputStream(file))
    val payload = Stream.continually(bis.read).takeWhile(-1 !=).map(_.toByte).toArray

    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val reader: DatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](schema)
    val decoder: Decoder = DecoderFactory.get().binaryDecoder(payload, null)

    val record: GenericRecord = reader.read(null, decoder)

    println(record.get("id"))
    println(record.get("name"))

  }
}
