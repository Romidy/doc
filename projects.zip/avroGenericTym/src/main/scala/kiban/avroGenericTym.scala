package kiban

import java.io.{BufferedOutputStream, ByteArrayOutputStream, File, FileOutputStream}

import org.apache.avro.Schema
import org.apache.avro.Schema.Parser
import org.apache.avro.io.{BinaryEncoder, Encoder, EncoderFactory}
import org.apache.avro.specific.SpecificDatumWriter

import scala.io.Source

object AvroGenericTym {

  def main(args: Array[String]): Unit = {
    val fileName = "can.avro"

    serializeSubmapRecord(fileName)

//    TymGenericWrite(fileName)
    //TymGenericRead(fileName)
    println("end")
  }

  /** CAN_Genericデータ */
  case class User(id: Int, name: String, email: Option[String])

  def serializeSubmapRecord(file:String) = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val can1 = User(1000000, "v001", Some("test"))

    // specific writer
    val writer = new SpecificDatumWriter[User](schema)
    val out = new ByteArrayOutputStream()
    val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
    writer.write(can1,encoder)
    encoder.flush()
    out.close()
    out.toByteArray()
    val bos = new BufferedOutputStream(new FileOutputStream(file))
    bos.write(out.toByteArray())
    bos.close()
   }

  /** TymGenericデータ */
  def TymGenericWrite(file: String): Unit = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)

    val can1 = User(1000000, "v001", Some("test"))
    val can2 = User(1000000, "v002", None)
    val cans = Seq(can1, can2)

    val os = AvroOutputStream.binary[User](new File(file), schema)
    os.write(cans)
    os.flush()
    os.close()
  }

  def TymGenericRead(file: String): Unit = {
  }
}
