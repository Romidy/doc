import java.io._

import com.sksamuel.avro4s.{AvroInputStream, AvroOutputStream}
import org.apache.avro.Schema
import org.apache.avro.Schema.Parser
import org.apache.avro.generic.{GenericData, GenericRecord}
import org.apache.avro.io._
import org.apache.avro.specific.{SpecificDatumReader, SpecificDatumWriter}
import org.apache.commons.io.output.ByteArrayOutputStream

import scala.io.Source

object Avro4sMain {


  def main(args: Array[String]): Unit = {
//        CanGenericWrite()
        CanGenericRead()

    //    CanWrite()
    //    CanRead()

    //    PizzaWrite()
    //    PizzaRead()
    //    PizzaBinaryWriteRead()

//        GenericWrite()
//        GenericRead()
  }

  /** CAN_Genericデータ */
  case class CanGeneric(id: Int, name: String, email: Option[String])

  def CanGenericWrite(): Unit = {
    val can1 = CanGeneric(1000000, "v001", Some("test"))
    val can2 = CanGeneric(1000000, "v002", None)

    val cans = Seq(can1, can2)

    val os = AvroOutputStream.data[CanGeneric](new File("canGeneric.avro"))
    os.write(cans)
    os.flush()
    os.close()
  }

  def CanGenericRead(): Unit = {
    val is = AvroInputStream.data[CanGeneric](new File("canGeneric.avro"))
    val deserializedCans = is.iterator.toSet
    is.close()
    deserializedCans.foreach(rec => {
      println(s"id[${rec.id}] name[${rec.name}] email[${rec.email match {case Some(f) => f case None => "nothing"}}]")
    })
  }

  /** CANデータ */
  case class GpsValue(double: Double)

  case class Gps(offset: Array[Long], lat: Array[GpsValue], lon: Array[GpsValue])

  case class Can(timestamp: Long, vin: String, gps: Array[Gps])

  def CanWrite(): Unit = {
    val can1 = Can(1000000, "v001", Array[Gps](Gps(Array[Long](100, 200), Array[GpsValue](GpsValue(15.1), GpsValue(15.2)), Array[GpsValue](GpsValue(135.1), GpsValue(135.2)))))
    val can2 = Can(1000000, "v002", Array[Gps](Gps(Array[Long](100, 200), Array[GpsValue](GpsValue(15.1), GpsValue(15.2)), Array[GpsValue](GpsValue(135.1), GpsValue(135.2)))))

    val cans = Seq(can1, can2)

    val os = AvroOutputStream.data[Can](new File("can.avro"))
    os.write(cans)
    os.flush()
    os.close()
  }

  def CanRead(): Unit = {
    val is = AvroInputStream.data[Can](new File("can.avro"))
    val deserializedCans = is.iterator.toSet
    is.close()
    deserializedCans.foreach(rec => {
      println(s"vin[${rec.vin}] timestamp[${rec.timestamp}]")
      for (gps <- rec.gps) {
        //        val len = gps.offset.length
        //        for (i <- len) {
        //
        //        }
      }

    })
  }

  /** Pizzaデータ */
  case class Ingredient(name: String, sugar: Double, fat: Double)

  case class Pizza(name: String, ingredients: Seq[Ingredient], vegetarian: Boolean, vegan: Boolean, calories: Int)

  def PizzaWrite(): Unit = {
    val pepperoni = Pizza("pepperoni", Seq(Ingredient("pepperoni", 12, 4.4), Ingredient("onions", 1, 0.4)), false, false, 98)
    val hawaiian = Pizza("hawaiian", Seq(Ingredient("ham", 1.5, 5.6), Ingredient("pineapple", 5.2, 0.2)), false, false, 91)
    val pizzaObjects = Seq(pepperoni, hawaiian)
    val os = AvroOutputStream.data[Pizza](new File("pizzas.avro"))
    os.write(pizzaObjects)
    os.flush()
    os.close()
  }

  def PizzaRead(): Unit = {
    val is = AvroInputStream.data[Pizza](new File("pizzas.avro"))
    val deserializedPizzas = is.iterator.toSet
    is.close()
    deserializedPizzas.foreach(println)
  }

  def PizzaBinaryWriteRead(): Unit = {
    val pepperoni = Pizza("pepperoni", Seq(Ingredient("pepperoni", 12, 4.4), Ingredient("onions", 1, 0.4)), false, false, 98)
    val hawaiian = Pizza("hawaiian", Seq(Ingredient("ham", 1.5, 5.6), Ingredient("pineapple", 5.2, 0.2)), false, false, 91)
    val pizzaObjects = Seq(pepperoni, hawaiian)

    val baos = new ByteArrayOutputStream()
    val output = AvroOutputStream.binary[Pizza](baos)
    output.write(pizzaObjects)
    output.close()
    val bytes = baos.toByteArray

    val in = new ByteArrayInputStream(bytes)
    val input = AvroInputStream.binary[Pizza](in)
    val deserializedPizzas2 = input.iterator.toSeq
    deserializedPizzas2.foreach(println)
    in.close()
  }

  /** Genericデータ */
  def GenericWrite(): Unit = {
    //Read avro schema file
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    // Create avro generic record object
    val genericUser: GenericRecord = new GenericData.Record(schema)
    //Put data in that generic record
    genericUser.put("id", 999999)
    genericUser.put("name", "sushil")
    genericUser.put("email", null)
    //    genericUser.put("ids", Array[Int](10, 20, 30))
    // Serialize generic record into byte array
    val writer = new SpecificDatumWriter[GenericRecord](schema)
    val out = new ByteArrayOutputStream()
    val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
    writer.write(genericUser, encoder)
    encoder.flush()
    out.close()
    out.toByteArray()
    val bos = new BufferedOutputStream(new FileOutputStream("generic.avro"))
    bos.write(out.toByteArray())
    bos.close()
  }

  def GenericRead(): Unit = {
    //    val bis = new BufferedInputStream(new FileInputStream("generic.avro"))
    val bis = new BufferedInputStream(new FileInputStream("canGeneric.avro"))
    val payload = Stream.continually(bis.read).takeWhile(-1 !=).map(_.toByte).toArray

    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)
    val reader: DatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](schema)
    val decoder: Decoder = DecoderFactory.get().binaryDecoder(payload, null)

    val record: GenericRecord = reader.read(null, decoder)

    println(record.get("id"))
    println(record.get("name"))

  }
}
