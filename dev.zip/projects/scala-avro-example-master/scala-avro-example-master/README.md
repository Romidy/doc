scala-avro-example
==================

Testing out Quinn Slack's compiler in his Scala branch of Avro:

`$ java -classpath "scala-avro.jar" org.apache.avro.scala.CompilerApp schema out EnronEmail.avsc`




