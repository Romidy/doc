package com.sksamuel.avro4s

import org.apache.avro.Schema

object AvroSchema {
  def apply[T](implicit schemaFor: SchemaFor[T]): Schema = schemaFor()
}
