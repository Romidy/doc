package com.sksamuel.avro4s;

public enum Wine {
    Malbec, Shiraz, CabSav, Merlot
}
