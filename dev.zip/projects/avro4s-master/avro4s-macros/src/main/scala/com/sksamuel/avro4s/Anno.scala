package com.sksamuel.avro4s

case class Anno(classname: String, values: Seq[String])
