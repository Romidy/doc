package kiban

import java.io.{File, OutputStream}
import java.nio.file.{Files, Path}

import org.apache.avro.Schema
import org.apache.avro.generic.{GenericDatumWriter, GenericRecord}
import org.apache.avro.io.EncoderFactory

trait AvroOutputStreamTym[T] {
  def close(): Unit
  def flush(): Unit
  def fSync(): Unit
  def write(t: T): Unit
  def write(ts: Seq[T]): Unit = ts.foreach(write)
}

case class AvroBinaryOutputStreamTym[T](os: OutputStream, schema: Schema)(implicit toRecord: ToRecordTym[T]) extends AvroOutputStreamTym[T] {

  val dataWriter = new GenericDatumWriter[GenericRecord](schema)
  val encoder = EncoderFactory.get().binaryEncoder(os, null)

  override def close(): Unit = {
    encoder.flush()
    os.close()
  }

  override def write(t: T): Unit = dataWriter.write(toRecord(t), encoder)

  override def flush(): Unit = encoder.flush()

  override def fSync(): Unit = ()
}

object AvroOutputStreamTym {
  def binary[T: ToRecordTym](file: File, schema: Schema): AvroBinaryOutputStreamTym[T] = binary(file.toPath, schema)

  def binary[T: ToRecordTym](path: Path, schema: Schema): AvroBinaryOutputStreamTym[T] = binary(Files.newOutputStream(path), schema)

  def binary[T: ToRecordTym](os: OutputStream, schema: Schema): AvroBinaryOutputStreamTym[T] = AvroBinaryOutputStreamTym(os, schema)
}
