package kiban

import java.io.File

import org.apache.avro.Schema
import org.apache.avro.Schema.Parser

import scala.io.Source

object avroGenericTym {

  def main(args: Array[String]): Unit = {
    val fileName = "can.avro"

    TymGenericWrite(fileName)
    //TymGenericRead(fileName)
  }

  /** CAN_Genericデータ */
  case class User(id: Int, name: String, email: Option[String])

  /** TymGenericデータ */
  def TymGenericWrite(file: String): Unit = {
    val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/generic.avsc")).mkString)

    val can1 = User(1000000, "v001", Some("test"))
    val can2 = User(1000000, "v002", None)
    val cans = Seq(can1, can2)

    val os = AvroOutputStream.binary[User](new File(file), schema)
    os.write(cans)
    os.flush()
    os.close()
  }

  def TymGenericRead(file: String): Unit = {
  }
}
