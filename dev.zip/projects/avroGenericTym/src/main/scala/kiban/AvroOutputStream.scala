package kiban

import java.io.{File, OutputStream}
import java.nio.file.{Files, Path}

import org.apache.avro.Schema
import org.apache.avro.file.{CodecFactory, DataFileWriter}
import org.apache.avro.generic.{GenericDatumWriter, GenericRecord}
import org.apache.avro.io.EncoderFactory

trait AvroOutputStream[T] {
  def close(): Unit
  def flush(): Unit
  def fSync(): Unit
  def write(t: T): Unit
  def write(ts: Seq[T]): Unit = ts.foreach(write)
}

// avro output stream that does not write the schema, only use when you want the smallest messages possible
// at the cost of not having the schema available in the messages for downstream clients
case class AvroBinaryOutputStream[T](os: OutputStream, schema: Schema)(implicit toRecord: ToRecord[T])
  extends AvroOutputStream[T] {

  val dataWriter = new GenericDatumWriter[GenericRecord](schema)
  val encoder = EncoderFactory.get().binaryEncoder(os, null)

  override def close(): Unit = {
    encoder.flush()
    os.close()
  }

  override def write(t: T): Unit = dataWriter.write(toRecord(t), encoder)
  override def flush(): Unit = encoder.flush()
  override def fSync(): Unit = ()
}


object AvroOutputStream {

  def binary[T: ToRecord](file: File, schema: Schema): AvroBinaryOutputStream[T] = binary(file.toPath,schema)
  def binary[T: ToRecord](path: Path, schema: Schema): AvroBinaryOutputStream[T] = binary(Files.newOutputStream(path),schema)
  def binary[T: ToRecord](os: OutputStream, schema: Schema): AvroBinaryOutputStream[T] = AvroBinaryOutputStream(os,schema)
}