import org.json4s.JObject
import org.json4s.jackson.JsonMethods.parse

object JsonSample {

  def main(args: Array[String]): Unit = {
    val fileName = "can.avro"

    println("start")
    val json =
      """
        {
          "name": "teat",
          "list": [10,20,30],
          "numbers" : [{"offset":0,"lat":35.1,"lon":139.1},{"offset":1,"lat":35.2,"lon":139.2}],
          "cans" : [{"_0x":null,"0xd":{"off":0,"speed":[0,10,20]},"0x99":"test"}]
        }
      """.stripMargin

    val jsonObj = parse(json)
    val map = jsonObj.asInstanceOf[JObject].values
    println(map)
    println(map.get("numbers").get.asInstanceOf[List[Any]](0).asInstanceOf[Map[String, Double]].get("lat").get)
    println(map.get("cans").get.asInstanceOf[List[Map[String, Any]]](0).get("0x99").get)
    println(map get "numbers")
    println(map get "cans")
    val canList: List[Map[String, Any]] = map.get("cans") match {
      case Some(x) => x.asInstanceOf[List[Map[String, Any]]]
      case None => List[Map[String, Any]]()
    }
    println(canList)
    println(canList(0).get("0x99").get)
    println(canList(0).get("0xd"))

    println(map get "list")
    val list: List[Int] = map.get("list") match {
      case Some(x) => x.asInstanceOf[List[Int]]
      case None => List[Int]()
    }
    println(list)


    val json2 = """{ "name" : "Toy", "price" : 35.35 }"""
    val jsonObj2 = parse(json2)
    val map2 = jsonObj2.asInstanceOf[JObject].values
    println(map2) //=> Map(name -> Toy, price -> 35.35)
    println(map2 get "price") //=> Some(35.35)
  }
}
